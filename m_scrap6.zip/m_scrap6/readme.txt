To run:

    If you haven't python installed, you have to installed python first.

    Then run first module_install.bat to install required modules.

    After installing modules, dbclick run.bat to fire scraping

+   Program will open several chrome browser to play as multi process, so don't close the browsers that opened automatically...
